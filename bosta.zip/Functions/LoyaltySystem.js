const { 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  ModalBuilder, 
  TextInputBuilder, 
  TextInputStyle,
  StringSelectMenuBuilder 
} = require('discord.js');
const fs = require('fs');
const path = require('path');

let loyaltyConfig = {
  rewards: [],
  points: {},
  enabledUsers: {}
};

module.exports = (client) => {
  client.on('interactionCreate', async interaction => {
    try {
      if (interaction.isButton()) {
        if (interaction.customId === 'loyalty_plan_system') {
          const userId = interaction.user.id;
          if (loyaltyConfig.enabledUsers[userId]) {
            await showLoyaltyOptions(interaction);
          } else {
            await askEnableLoyaltySystem(interaction);
          }
        } else if (interaction.customId === 'enable_loyalty_yes') {
          const userId = interaction.user.id;
          loyaltyConfig.enabledUsers[userId] = true;
          saveLoyaltyConfig();
          await interaction.update({ content: 'Sistema de Fidelidade habilitado!', components: [], ephemeral: true });
          await showLoyaltyOptions(interaction);
        } else if (interaction.customId === 'enable_loyalty_no') {
          await interaction.update({ content: 'Sistema de Fidelidade não habilitado.', components: [], ephemeral: true });
        } else if (interaction.customId === 'add_reward') {
          const modal = new ModalBuilder()
            .setCustomId('add_reward_modal')
            .setTitle('Adicionar Recompensa');

          const nameInput = new TextInputBuilder()
            .setCustomId('reward_name')
            .setLabel('Nome da Recompensa')
            .setStyle(TextInputStyle.Short);

          const pointsInput = new TextInputBuilder()
            .setCustomId('reward_points')
            .setLabel('Pontos Necessários')
            .setStyle(TextInputStyle.Short);

          const modalRow1 = new ActionRowBuilder().addComponents(nameInput);
          const modalRow2 = new ActionRowBuilder().addComponents(pointsInput);

          modal.addComponents(modalRow1, modalRow2);

          await interaction.showModal(modal);
        } else if (interaction.customId === 'view_rewards') {
          const rewards = loyaltyConfig.rewards.map(r => `${r.name}: ${r.points} pontos`).join('\n');
          await interaction.reply({ content: `Recompensas disponíveis:\n${rewards}`, ephemeral: true });
        } else if (interaction.customId === 'view_users') {
          const userPoints = Object.entries(loyaltyConfig.points).map(([id, points]) => `<@${id}>: ${points} pontos`).join('\n');
          await interaction.reply({ content: `Pontos dos usuários:\n${userPoints}`, ephemeral: true });
        } else if (interaction.customId === 'remove_reward') {
          const rewards = loyaltyConfig.rewards.map((r, index) => ({ label: r.name, value: index.toString() }));
          const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('remove_reward_select')
            .setPlaceholder('Selecione uma recompensa para remover')
            .addOptions(rewards);

          const row = new ActionRowBuilder().addComponents(selectMenu);

          await interaction.reply({ content: 'Selecione uma recompensa para remover:', components: [row], ephemeral: true });
        }
      } else if (interaction.isStringSelectMenu()) {
        if (interaction.customId === 'remove_reward_select') {
          const rewardIndex = parseInt(interaction.values[0], 10);
          loyaltyConfig.rewards.splice(rewardIndex, 1);
          saveLoyaltyConfig();
          await interaction.update({ content: 'Recompensa removida com sucesso!', components: [], ephemeral: true });
        }
      } else if (interaction.isModalSubmit()) {
        if (interaction.customId === 'add_reward_modal') {
          const name = interaction.fields.getTextInputValue('reward_name');
          const points = parseInt(interaction.fields.getTextInputValue('reward_points'), 10);

          loyaltyConfig.rewards.push({ name, points });
          saveLoyaltyConfig();

          await interaction.reply({ content: `Recompensa ${name} adicionada com sucesso!`, ephemeral: true });
        }
      }
    } catch (error) {
      console.error('Erro detectado:', error);
    }
  });

  client.on('messageCreate', message => {
    if (!message.author.bot) {
      const userId = message.author.id;
      if (!loyaltyConfig.points[userId]) {
        loyaltyConfig.points[userId] = 0;
      }

      loyaltyConfig.points[userId] += 1;
      saveLoyaltyConfig();
    }
  });

  setInterval(async () => {
    const filePath = path.join(__dirname, '..', 'DataBaseJson', 'estatisticas.json');
    const estatisticas = require('../DataBaseJson/estatisticas.json');
    for (const [key, value] of Object.entries(estatisticas)) {
      if (value.idpagamento === 'Aprovado') {
        const userId = value.userid;
        if (!loyaltyConfig.points[userId]) {
          loyaltyConfig.points[userId] = 0;
        }
        loyaltyConfig.points[userId] += 1;
        saveLoyaltyConfig();
        await checkRewards(userId, client);
      }
    }
  }, 60000);

  async function checkRewards(userId, client) {
    const userPoints = loyaltyConfig.points[userId];
    for (const reward of loyaltyConfig.rewards) {
      if (userPoints >= reward.points) {
        const user = await client.users.fetch(userId);
        await user.send(`Parabéns! Você atingiu ${reward.points} pontos e ganhou a recompensa: ${reward.name}. Por favor, abra um ticket para reivindicar sua recompensa.`);
      }
    }
  }

  function saveLoyaltyConfig() {
    const filePath = path.join(__dirname, '..', 'DataBaseJson', 'loyaltyConfig.json');
    fs.writeFileSync(filePath, JSON.stringify(loyaltyConfig, null, 4));
  }

  function loadLoyaltyConfig() {
    const filePath = path.join(__dirname, '..', 'DataBaseJson', 'loyaltyConfig.json');
    if (fs.existsSync(filePath)) {
      loyaltyConfig = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    }
  }

  loadLoyaltyConfig();
}

async function askEnableLoyaltySystem(interaction) {
  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('enable_loyalty_yes')
        .setLabel('Sim')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('enable_loyalty_no')
        .setLabel('Não')
        .setStyle(ButtonStyle.Danger)
    );

  await interaction.reply({ content: 'Gostaria de habilitar este sistema?', components: [row], ephemeral: true });
}

async function showLoyaltyOptions(interaction) {
  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('add_reward')
        .setLabel('Adicionar Recompensa')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('view_rewards')
        .setLabel('Ver Recompensas')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('view_users')
        .setLabel('Ver Usuários')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('remove_reward')
        .setLabel('Remover Recompensa')
        .setStyle(ButtonStyle.Danger)
    );

  await interaction.reply({ content: 'Escolha uma opção para configurar o sistema de fidelidade:', components: [row], ephemeral: true });
}