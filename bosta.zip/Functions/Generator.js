const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, AttachmentBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const baseLinkMensal = "https://discord.com/billing/partner-promotions/1180231712274387115/eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..r0aFlkXx3TkBdh2w.-SQ8B_mjSn4uCj2iA3sH5xaN4xFQ_nwgq7hX_lMcuhvGXxJF4mHG7azEfCn_hrvjanmsvjrJ7_bLGRQRvZnxKez4l9uQ8Eswn2JYDqYlLlqQJLcFWmwBLGXV_MzIeV3iig58GsQgP1gw4DjAkLmPbSmUr_6a8wsLmwxeSnWVFNbdL3OBaKobb2TCrPPzW2KMQ1v4Yi3Y9chVNtaBeexCY2Olv-BLZMY3gdj4aOv-gx-";
const baseLinkGift = "https://discord.gift/ujmYxTkBVaEr3lXu";

function generateLink(base) {
    const code = require('crypto').randomBytes(16).toString('base64').replace(/[^a-zA-Z0-9]/g, '');
    return base + code;
}

module.exports = (client) => { 
  client.on('interactionCreate', async interaction => {
    const embed = new EmbedBuilder()
    .setColor(`#2d2d31`) 
    .setDescription(`Olá, senhor(a) ${interaction.user}, o que deseja fazer?`)
    .addFields(
      { name: `**Versão do Sistema**`, value: `\`1.0.0\``, inline: true },
      { name: `**Servidor**`, value: `\`${interaction.guild.name}\``, inline: true },
    )
    .setFooter(
      { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
    )
    .setTimestamp();
    if (interaction.isButton()) {
      if (interaction.customId === 'generator') {
        const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('link_trimensal')
              .setLabel('Link Trimensal')
              .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
              .setCustomId('link_mensal')
              .setLabel('Link Mensal')
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId('link_gift')
              .setLabel('Link Gift')
              .setStyle(ButtonStyle.Secondary),
              new ButtonBuilder()
              .setCustomId('desabilitadomeucoração')
              .setLabel('1.0.0')
              .setStyle(ButtonStyle.Secondary)
              .setDisabled(true)
          );

        await interaction.reply({ content: 'Seja bem vindo ao Generator System!', embeds: [embed] , components: [row], ephemeral: true });
      } else if (interaction.customId === 'link_trimensal' || interaction.customId === 'link_mensal' || interaction.customId === 'link_gift') {
        const modalId = interaction.customId === 'link_trimensal' ? 'generate_links_trimensal_modal' :
                        interaction.customId === 'link_mensal' ? 'generate_links_mensal_modal' : 
                        'generate_links_gift_modal';
        const modalTitle = interaction.customId === 'link_trimensal' ? 'Gerar Links Trimestrais' :
                           interaction.customId === 'link_mensal' ? 'Gerar Links Mensais' : 
                           'Gerar Links Gift';
        
        const modal = new ModalBuilder()
          .setCustomId(modalId)
          .setTitle(modalTitle);

        const quantidadeInput = new TextInputBuilder()
          .setCustomId('quantidade')
          .setLabel('Quantos Links você quer gerar?')
          .setStyle(TextInputStyle.Short)
          .setMaxLength(6);

        const modalRow = new ActionRowBuilder().addComponents(quantidadeInput);

        modal.addComponents(modalRow);

        await interaction.showModal(modal);
      }
    } else if (interaction.isModalSubmit()) {
      if (interaction.customId === 'generate_links_trimensal_modal' || interaction.customId === 'generate_links_mensal_modal' || interaction.customId === 'generate_links_gift_modal') {
        const quantidade = parseInt(interaction.fields.getTextInputValue('quantidade'), 10);

        if (isNaN(quantidade) || quantidade <= 0 || quantidade > 999999) {
          await interaction.reply({ content: 'Por favor, insira um número válido entre 1 e 999999.', ephemeral: true });
          return;
        }

        const fileName = interaction.customId === 'generate_links_trimensal_modal' ? 'trimensais.txt' :
                         interaction.customId === 'generate_links_mensal_modal' ? 'mensais.txt' : 
                         'gifts.txt';
        const base = interaction.customId === 'generate_links_trimensal_modal' ? 'https://discord.com/billing/promotions/' :
                     interaction.customId === 'generate_links_mensal_modal' ? baseLinkMensal : 
                     baseLinkGift;

        await gerarCodigos(quantidade, base, fileName);

        const file = new AttachmentBuilder(path.join(__dirname, fileName));

        await interaction.reply({ content: 'Aqui estão os links gerados:', files: [file], ephemeral: true });
      }
    }
  });

  async function gerarCodigos(quantidade, base, fileName) {
    const codigos = [];

    for (let i = 0; i < quantidade; i++) {
      codigos.push(generateLink(base));
    }

    fs.writeFileSync(path.join(__dirname, fileName), codigos.join('\n'));
  }
};
