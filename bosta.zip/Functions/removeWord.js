const fs = require("fs");
const path = require("path");
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require("discord.js");

const palavrasPath = path.join(__dirname, '../DataBaseJson/palavras.json');
let palavrasFiltradas = require(palavrasPath);

async function removeWord(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('removeWordModal')
    .setTitle('Remover Palavra do Filtro')
    .addComponents(
      new TextInputBuilder()
        .setCustomId('wordInput')
        .setLabel('Palavra')
        .setStyle(TextInputStyle.Short)
    );

  await interaction.showModal(modal);
}

async function handleModalSubmit(interaction) {
  const word = interaction.fields.getTextInputValue('wordInput');
  const wordIndex = palavrasFiltradas.indexOf(word);
  if (wordIndex === -1) {
    await interaction.reply({
      content: `A palavra "${word}" não está no filtro.`,
      ephemeral: true,
    });
  } else {
    palavrasFiltradas.splice(wordIndex, 1);
    fs.writeFileSync(palavrasPath, JSON.stringify(palavrasFiltradas, null, 2));
    await interaction.reply({
      content: `A palavra "${word}" foi removida do filtro.`,
      ephemeral: true,
    });
  }
}

module.exports = {
  removeWord,
  handleModalSubmit,
};