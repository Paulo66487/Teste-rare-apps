const fs = require("fs");
const path = require("path");
const { ActionRowBuilder, TextInputBuilder, ModalBuilder, TextInputStyle } = require("discord.js");

const palavrasPath = path.join(__dirname, '../DataBaseJson/palavras.json');
let palavrasFiltradas = require(palavrasPath);

async function addWord(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('addWordModal')
    .setTitle('Adicionar Palavra ao Filtro');

  const wordInput = new TextInputBuilder()
    .setCustomId('wordInput')
    .setLabel('Palavra')
    .setStyle(TextInputStyle.Short);

  const firstActionRow = new ActionRowBuilder().addComponents(wordInput);

  modal.addComponents(firstActionRow);

  await interaction.showModal(modal);
}

async function handleModalSubmit(interaction) {
  const word = interaction.fields.getTextInputValue('wordInput');
  if (palavrasFiltradas.includes(word)) {
    await interaction.reply({
      content: `A palavra "${word}" já está no filtro.`,
      ephemeral: true,
    });
  } else {
    palavrasFiltradas.push(word);
    fs.writeFileSync(palavrasPath, JSON.stringify(palavrasFiltradas, null, 2));
    await interaction.reply({
      content: `A palavra "${word}" foi adicionada ao filtro.`,
      ephemeral: true,
    });
  }
}

module.exports = {
  addWord,
  handleModalSubmit,
};
