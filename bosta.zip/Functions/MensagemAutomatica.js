const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

let messageInterval;

module.exports = (client) => {
    client.on('interactionCreate', async (interaction) => {
        if (interaction.isCommand()) {
            const command = client.commands?.get(interaction.commandName);
            if (!command) {
                //console.error(`Comando ${interaction.commandName} não encontrado.`);
                return;
            }

            try {
                await command.execute(interaction);
            } catch (error) {
                console.error('Erro ao executar o comando:', error);
                await interaction.reply({ content: 'Houve um erro ao executar esse comando!', ephemeral: true });
            }
        } else if (interaction.isButton()) {
            switch (interaction.customId) {
                case 'automatic_message':
                    await interaction.reply({ content: 'Configuração de Mensagem Automática.', ephemeral: true });

                    const row = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId('set_channel')
                                .setLabel('Setar Canal de Mensagem')
                                .setStyle(ButtonStyle.Primary),
                            new ButtonBuilder()
                                .setCustomId('config_message')
                                .setLabel('Config Mensagem')
                                .setStyle(ButtonStyle.Primary),
                            new ButtonBuilder()
                                .setCustomId('config_interval')
                                .setLabel('Config Intervalo')
                                .setStyle(ButtonStyle.Primary),
                            new ButtonBuilder()
                                .setCustomId('toggle_system')
                                .setLabel('Sistema: OFF')
                                .setStyle(ButtonStyle.Danger)
                        );

                    await interaction.followUp({ content: 'Escolha uma opção para configurar:', components: [row], ephemeral: true });
                    break;

                case 'set_channel':
                    if (!interaction.guild) {
                        await interaction.reply({ content: 'Interação não está em um servidor.', ephemeral: true });
                        return;
                    }

                    const channels = interaction.guild.channels.cache
                        .filter(c => c.type === ChannelType.GuildText)
                        .map(channel => ({ name: channel.name, id: channel.id }))
                        .slice(0, 25);

                    console.log('Text channels found:', channels);

                    const options = channels.map(channel => ({
                        label: channel.name,
                        value: channel.id
                    }));

                    if (options.length === 0) {
                        await interaction.reply({ content: 'Nenhum canal de texto encontrado.', ephemeral: true });
                        return;
                    }

                    const selectMenu = new StringSelectMenuBuilder()
                        .setCustomId('select_channel')
                        .setPlaceholder('Selecione um canal')
                        .setMinValues(1)
                        .setMaxValues(options.length)
                        .addOptions(options);

                    const selectRow = new ActionRowBuilder().addComponents(selectMenu);

                    await interaction.reply({ content: 'Selecione um canal para enviar as mensagens:', components: [selectRow], ephemeral: true });
                    break;

                case 'config_message':
                    const messageModal = new ModalBuilder()
                        .setCustomId('config_modal')
                        .setTitle('Configurar Mensagem');

                    const titleInput = new TextInputBuilder()
                        .setCustomId('title')
                        .setLabel('Título')
                        .setStyle(TextInputStyle.Short);

                    const descriptionInput = new TextInputBuilder()
                        .setCustomId('description')
                        .setLabel('Descrição')
                        .setStyle(TextInputStyle.Paragraph);

                    const colorInput = new TextInputBuilder()
                        .setCustomId('color')
                        .setLabel('Cor (HEX)')
                        .setStyle(TextInputStyle.Short);

                    const imageInput = new TextInputBuilder()
                        .setCustomId('image')
                        .setLabel('URL da Imagem (Opcional)')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(false);

                    messageModal.addComponents(
                        new ActionRowBuilder().addComponents(titleInput),
                        new ActionRowBuilder().addComponents(descriptionInput),
                        new ActionRowBuilder().addComponents(colorInput),
                        new ActionRowBuilder().addComponents(imageInput)
                    );

                    await interaction.showModal(messageModal);
                    break;

                case 'config_interval':
                    const intervalModal = new ModalBuilder()
                        .setCustomId('interval_modal')
                        .setTitle('Configurar Intervalo');

                    const intervalInput = new TextInputBuilder()
                        .setCustomId('interval')
                        .setLabel('Intervalo (minutos)')
                        .setStyle(TextInputStyle.Short);

                    intervalModal.addComponents(new ActionRowBuilder().addComponents(intervalInput));

                    await interaction.showModal(intervalModal);
                    break;

                case 'toggle_system':
                    const config = loadConfig();
                    const systemOn = !config.systemOn;
                    saveConfig({ systemOn });

                    await interaction.update({
                        components: [
                            new ActionRowBuilder()
                                .addComponents(
                                    new ButtonBuilder()
                                        .setCustomId('set_channel')
                                        .setLabel('Setar Canal de Mensagem')
                                        .setStyle(ButtonStyle.Primary),
                                    new ButtonBuilder()
                                        .setCustomId('config_message')
                                        .setLabel('Config Mensagem')
                                        .setStyle(ButtonStyle.Primary),
                                    new ButtonBuilder()
                                        .setCustomId('config_interval')
                                        .setLabel('Config Intervalo')
                                        .setStyle(ButtonStyle.Primary),
                                    new ButtonBuilder()
                                        .setCustomId('toggle_system')
                                        .setLabel(systemOn ? 'Sistema: ON' : 'Sistema: OFF')
                                        .setStyle(systemOn ? ButtonStyle.Success : ButtonStyle.Danger)
                                )
                        ]
                    });

                    if (systemOn) {
                        startMessageInterval();
                    } else {
                        clearInterval(messageInterval);
                    }
                    break;
            }
        } else if (interaction.isStringSelectMenu()) {
            if (interaction.customId === 'select_channel') {
                const channelIds = interaction.values;
                saveConfig({ channelIds });
                const channelNames = channelIds.map(id => interaction.guild?.channels.cache.get(id)?.name || 'Desconhecido').join(', ');
                await interaction.reply({ content: `Canais selecionados para envio de mensagens: ${channelNames}.`, ephemeral: true });
            }
        } else if (interaction.isModalSubmit()) {
            if (interaction.customId === 'config_modal') {
                const title = interaction.fields.getTextInputValue('title');
                const description = interaction.fields.getTextInputValue('description');
                const color = interaction.fields.getTextInputValue('color');
                const image = interaction.fields.getTextInputValue('image');

                saveConfig({ title, description, color, image });
                await interaction.reply({ content: `Configurações salvas:\nTítulo: ${title}\nDescrição: ${description}\nCor: ${color}\nImagem: ${image || 'Nenhuma'}`, ephemeral: true });
            } else if (interaction.customId === 'interval_modal') {
                const interval = interaction.fields.getTextInputValue('interval');

                saveConfig({ interval });
                await interaction.reply({ content: `Intervalo salvo: ${interval} minutos.`, ephemeral: true });
                startMessageInterval();
            }
        }
    });

    function saveConfig(newConfig) {
        const filePath = path.join(__dirname, '..', 'DataBaseJson', 'mensagem.json');
        let config = {};

        if (fs.existsSync(filePath)) {
            config = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        }

        const updatedConfig = { ...config, ...newConfig };

        fs.writeFileSync(filePath, JSON.stringify(updatedConfig, null, 4));
    }

    function loadConfig() {
        const filePath = path.join(__dirname, '..', 'DataBaseJson', 'mensagem.json');
        if (fs.existsSync(filePath)) {
            return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        }
        return {};
    }

    async function sendMessage() {
        const config = loadConfig();
        if (!config.systemOn) return;

        const embed = new EmbedBuilder()
            .setTitle(config.title || 'Sem Título')
            .setDescription(config.description || 'Sem Descrição')
            .setColor(config.color || '#2b2d31');

        if (config.image) {
            embed.setImage(config.image);
        }

        for (const channelId of config.channelIds || []) {
            try {
                const channel = await client.channels.fetch(channelId);
                if (channel?.isTextBased()) {
                    const row = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId('disable')
                                .setLabel('Mensagem Automática')
                                .setStyle(ButtonStyle.Secondary)
                                .setDisabled(true),
                        );

                    await channel.send({ embeds: [embed], components: [row] });
                }
            } catch (error) {
                console.error(`Erro ao enviar mensagem para o canal ${channelId}:`, error);
            }
        }
    }

    function startMessageInterval() {
        const config = loadConfig();
        if (!config.interval) return;

        const interval = parseInt(config.interval, 10) * 60 * 1000;

        if (messageInterval) {
            clearInterval(messageInterval);
        }

        messageInterval = setInterval(sendMessage, interval);
    }
}
