const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js");
const fs = require("fs");
const path = require("path");
const { Painel } = require('./Painel.js');

const palavrasPath = path.join(__dirname, '../DataBaseJson/palavras.json');
let palavrasFiltradas = require(palavrasPath);

const salvosPath = path.join(__dirname, '../DataBaseJson/salvos.json');
let salvos = require(salvosPath);

if (!Array.isArray(palavrasFiltradas)) {
  palavrasFiltradas = [];
}

let spamDetectionEnabled = false;

async function detectarSpam(interaction) {
  const spamRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('toggle_spam_detection')
        .setLabel('SISTEM: OFF')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('back_to_moderation')
        .setLabel('Voltar')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.update({
    content: "Configuração de detecção de spam:",
    components: [spamRow],
    embeds: [],
    ephemeral: true,
  });
}

async function filtrarPalavras(interaction) {
  const wordFilterEmbed = new EmbedBuilder()
    .setColor('#2d2d31')
    .setTitle('Configuração de Filtragem de Palavras')
    .setDescription('Aqui estão as palavras atualmente filtradas:')
    .addFields(
      palavrasFiltradas.map(palavra => ({ name: palavra, value: '\u200B' }))
    );

  const wordFilterRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('add_word')
        .setLabel('Adicionar Palavra')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('remove_word')
        .setLabel('Remover Palavra')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('back_to_moderation')
        .setLabel('Voltar')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.update({
    content: "",
    components: [wordFilterRow],
    embeds: [wordFilterEmbed],
    ephemeral: true,
  });
}

async function handleModerationSettings(interaction) {
  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('detectar_spam')
        .setLabel('Anti Spam')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('filtrar_palavras')
        .setLabel('Filtragem de Palavras')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('back_to_main')
        .setLabel('Voltar')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('idk')
        .setLabel('BETA')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true)
    );

  await interaction.update({
    content: "Configurações de Moderação:",
    components: [row],
    embeds: [],
    ephemeral: true,
  });
}

async function handleInteraction(interaction) {
  switch (interaction.customId) {
    case "detectar_spam":
      await detectarSpam(interaction);
      break;
    case "filtrar_palavras":
      await filtrarPalavras(interaction);
      break;
    case "add_word":
      await addWord(interaction);
      break;
    case "remove_word":
      await removeWord(interaction);
      break;
    case "toggle_spam_detection":
      await toggleSpamDetection(interaction);
      break;
    case "set_log_channel":
      await setLogChannel(interaction);
      break;
    case "back_to_moderation":
      await handleModerationSettings(interaction);
      break;
    case "back_to_main":
      await Painel(interaction, interaction.client);
      break;
    default:
      break;
  }
}

let messageCreateListener;
const messageCache = new Map();

async function toggleSpamDetection(interaction) {
  spamDetectionEnabled =!spamDetectionEnabled;
  const buttonLabel = spamDetectionEnabled? 'SISTEM: ON' : 'SISTEM: OFF';
  const buttonStyle = spamDetectionEnabled? ButtonStyle.Success : ButtonStyle.Danger;

  const spamRow = new ActionRowBuilder()
   .addComponents(
      new ButtonBuilder()
       .setCustomId('toggle_spam_detection')
       .setLabel(buttonLabel)
       .setStyle(buttonStyle),
      new ButtonBuilder()
       .setCustomId('back_to_moderation')
       .setLabel('Voltar')
       .setStyle(ButtonStyle.Secondary)
    );

  await interaction.update({
    content: "Configuração de detecção de spam:",
    components: [spamRow],
    embeds: [],
    ephemeral: true,
  });

  if (spamDetectionEnabled) {
    messageCreateListener = async (message) => {
      if (message.author.bot) return;
      const userId = message.author.id;
      const currentTime = Date.now();
      const messages = messageCache.get(userId) || [];
      messages.push({ message, timestamp: currentTime });
      messageCache.set(userId, messages);

      setTimeout(() => {
        messageCache.set(userId, messages.filter((msg) => msg.timestamp > currentTime - 1500));
      }, 1500);

      const recentMessages = messages.filter((msg) => msg.timestamp > currentTime - 1500);
      if (recentMessages.length > 5) {
        recentMessages.forEach((msg) => msg.message.delete().catch(console.error));
      }
    };
    interaction.client.on('messageCreate', messageCreateListener);
  } else {
    interaction.client.off('messageCreate', messageCreateListener);
    messageCreateListener = null;
    messageCache.clear();
  }
}

async function addWord(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('addWordModal')
    .setTitle('Adicionar Palavra ao Filtro');

  const wordInput = new TextInputBuilder()
    .setCustomId('wordInput')
    .setLabel('Palavra')
    .setStyle(TextInputStyle.Short);

  const firstActionRow = new ActionRowBuilder().addComponents(wordInput);

  modal.addComponents(firstActionRow);

  await interaction.showModal(modal);
}

async function removeWord(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('removeWordModal')
    .setTitle('Remover Palavra do Filtro');

  const wordInput = new TextInputBuilder()
    .setCustomId('wordInput')
    .setLabel('Palavra')
    .setStyle(TextInputStyle.Short);

  const firstActionRow = new ActionRowBuilder().addComponents(wordInput);

  modal.addComponents(firstActionRow);

  await interaction.showModal(modal);
}

function handleMessage(message) {
  if (message.author.bot) return;

  const messageContent = message.content.toLowerCase();
  const hasFilteredWord = palavrasFiltradas.some(palavra => messageContent.includes(palavra.toLowerCase()));

  if (hasFilteredWord) {
    message.delete().catch(console.error);
  }
}

async function handleModalSubmit(interaction) {
  if (interaction.customId === 'setLogChannelModal') {
    const channelId = interaction.fields.getTextInputValue('channelIdInput');
    salvos.logChannelId = channelId;

    fs.writeFileSync(salvosPath, JSON.stringify(salvos, null, 2), 'utf-8');

    await interaction.reply({ content: `Canal de logs setado para: ${channelId}`, ephemeral: true });
  }
}

module.exports = {
  handleInteraction,
  handleModerationSettings,
  detectarSpam,
  filtrarPalavras,
  toggleSpamDetection,
  addWord,
  removeWord,
  handleMessage,
  handleModalSubmit
};
