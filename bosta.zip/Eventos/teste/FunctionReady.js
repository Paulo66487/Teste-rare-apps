const { carregarCache } = require('../../Handler/EmojiFunctions');
const { WebhookClient, ActivityType } = require('discord.js');
const { CloseThreds } = require('../../Functions/CloseThread');
const { VerificarPagamento } = require('../../Functions/VerficarPagamento');
const { EntregarPagamentos } = require('../../Functions/AprovarPagamento');
const { CheckPosition } = require('../../Functions/PosicoesFunction.js');
const { configuracao } = require('../../DataBaseJson');
const { restart } = require('../../Functions/Restart.js');
const { Varredura } = require('../../Functions/Varredura.js');

module.exports = {
    name: 'ready',

    run: async (client) => {
        const configuracoes = ['Status1', 'Status2'];
        let indiceAtual = 0;

        function setActivityWithInterval(client, configuracoes, type, interval) {
            setInterval(() => {
                const configuracaoKey = configuracoes[indiceAtual];
                const status = configuracao.get(configuracaoKey);

                if (status !== null) {
                    client.user.setActivity(status, { type });
                }

                indiceAtual = (indiceAtual + 1) % configuracoes.length;
            }, interval);
        }

        setActivityWithInterval(client, configuracoes, ActivityType.Playing, 5000);

        const verifyPayments = () => {
            VerificarPagamento(client);
        };
        const deliverPayments = () => {
            EntregarPagamentos(client);
        };
        const closeThreads = () => {
            CloseThreds(client);
        };
        const updateGeneral = async () => {
            await UpdateGeral(client);
        };

        Varredura(client);

        const config = {
            method: 'GET',
            headers: {
                'token': 'ac3add76c5a3c9fd6952a#'
            }
        };

        // Aqui fazemos a requisição e verificamos o tipo de conteúdo da resposta
        try {
            const response = await fetch(`http://apivendas.squareweb.app/api/v1/Console2/${client.user.id}`, config);
            
            // Verificamos se o conteúdo da resposta é JSON
            const contentType = response.headers.get("content-type");
            if (contentType && contentType.includes("application/json")) {
                const info = await response.json();
                
                if (info.status === 'foi') {
                    restart(client, 1);
                } else {
                    restart(client, 0);
                }
            } else {
                // Caso a resposta não seja JSON, exibimos o conteúdo retornado
                //console.error('A resposta não contém JSON:', await response.text());
            }
        } catch (error) {
            //console.error('Erro ao fazer requisição:', error);
        }

        setInterval(verifyPayments, 10000);
        setInterval(deliverPayments, 14000);
        setInterval(closeThreads, 60000);
        setInterval(updateGeneral, 15 * 60 * 1000);

        async function UpdateGeral(client) {
            let config = {
                method: 'GET',
                headers: {
                    'token': 'ac3add76c5a3c9fd6952a#'
                }
            };

            const description = "**Rare Apps**\n\nhttps://discord.gg/caejtpfvpr";

            try {
                const addonsFetch = await fetch(`http://apivendas.squareweb.app/api/v1/adicionais/${client.user.id}`, config);

                if (addonsFetch) {
                    const contentType = addonsFetch.headers.get("content-type");

                    if (contentType && contentType.includes("application/json")) {
                        const addonsData = await addonsFetch.json();
                        
                        if (addonsData && addonsData?.adicionais?.RemoverAnuncio !== true) {
                            const endpoint = `https://discord.com/api/v9/applications/${client.user.id}`;
                            const headers = {
                                "Authorization": `Bot ${client.token}`,
                                "Content-Type": "application/json"
                            };

                            const response = await fetch(endpoint, { headers, method: "PATCH", body: JSON.stringify({}) });
                            const body = await response.json();

                            if (body && JSON.stringify(body.description) !== JSON.stringify(description)) {
                                await fetch(endpoint, { headers, method: "PATCH", body: JSON.stringify({ description }) }).catch(() => null);
                            }
                        }
                    } else {
                        //console.error('Resposta não contém JSON:', await addonsFetch.text());
                    }
                }
            } catch (error) {
               // console.error('Erro ao fazer requisição para UpdateGeral:', error);
            }
        }

        CheckPosition(client);
        carregarCache();
    }
}
