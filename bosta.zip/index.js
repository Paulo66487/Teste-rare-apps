const { GatewayIntentBits, Client, Collection, Partials } = require("discord.js");
const express = require("express");
const { AtivarIntents } = require("./Functions/StartIntents");
const { Painel, Gerenciar2 } = require('./Functions/Painel');
const { handleInteraction, handleModerationSettings } = require('./Functions/moderationSettings');
const { addWord, handleModalSubmit: handleAddWordModalSubmit } = require('./Functions/addWord');
const { removeWord, handleModalSubmit: handleRemoveWordModalSubmit } = require('./Functions/removeWord');
const estatisticasStormInstance = require("./Functions/VariaveisEstatisticas");
const EstatisticasStorm = new estatisticasStormInstance();
const config = require("./config.json");
const events = require('./Handler/events');
const slash = require('./Handler/slash');
const fs = require('fs');
const moderation = require('./Functions/moderationSettings.js');

const app = express();
const client = new Client({
    intents: Object.values(GatewayIntentBits),
    partials: Object.values(Partials)
    
});
//dryzz passsou aki
client.setMaxListeners(999);
const palavrasProibidas = JSON.parse(fs.readFileSync('./DataBaseJson/palavras.json', 'utf8'));

client.on('messageCreate', (message) => {
  if (message.author.bot) return;

  const mensagem = message.content.toLowerCase();
  for (const palavra of palavrasProibidas) {
    if (mensagem.includes(palavra.toLowerCase())) {
      message.delete().catch((err) => console.error(err));
      return;
    }
  }
});

module.exports = { EstatisticasStorm };

AtivarIntents();

slash.run(client);
events.run(client);

client.slashCommands = new Collection();

require('./Functions/MensagemAutomatica')(client);
require('./Functions/LoyaltySystem')(client);
require('./Functions/Generator')(client);

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;
  

  try {
    switch (interaction.customId) {
      case 'moderationsettings':
        await moderation.handleModerationSettings(interaction);
        break;
      // Adicione outros cases aqui para outras interações de botão
      default:
        break;
    }
  } catch (error) {
    console.error(error);
    await interaction.reply({ content: 'Houve um erro ao executar essa ação!', ephemeral: true });
  }
});

client.on('interactionCreate', async interaction => {
  if (interaction.isButton()) {
    await handleInteraction(interaction);
  } else if (interaction.isModalSubmit()) {
    if (interaction.customId === 'addWordModal') {
      await handleAddWordModalSubmit(interaction);
    } else if (interaction.customId === 'removeWordModal') {
      await handleRemoveWordModalSubmit(interaction);
    }
  }
});

//process.on('unhandledRejection', (reason, promise) => {
//});
//process.on('uncaughtException', (error, origin) => {
//});
//process.on('uncaughtExceptionMonitor', (error, origin) => {
//});

const login = require("./routes/login");
app.use("/", login);

const callback = require("./routes/callback");
app.use("/", callback);

try {
  app.listen({
    host: "0.0.0.0",
    port: process.env.PORT ? Number(process.env.PORT) : config.port
  }, () => {
    console.log("HTTP Process Running");
  });
} catch (err) {
  console.error("Failed to start server:", err);
}

client.login(config.token);
